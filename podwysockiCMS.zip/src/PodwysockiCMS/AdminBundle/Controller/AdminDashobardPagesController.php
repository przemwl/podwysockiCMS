<?php

namespace PodwysockiCMS\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

class AdminDashobardPagesController extends Controller
{
    public function indexAction()
    {
       $user = $this->get('security.token_storage')->getToken()->getUser();
        
//     $avatarSrc = $user->getAvatarSrc();
       $username = $user->getUsername();
        return $this->render('AdminBundle:AdminDashobard:dashboard-pages/pages.html.twig',array(
            'username' => $username
//            'avatarSrc' =>  $avatarSrc);
                ));
    }
}
