<?php

/* AdminBundle:Default:index.html.twig */
class __TwigTemplate_954949ed1d5e7ed5f7e78920718db1dc26d9fbfbe8acbfd204bcc2d9e873a5c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5344a2540bcac17e1735d6f1f4a323e143aea618ce6a871953488cbcda4f983f = $this->env->getExtension("native_profiler");
        $__internal_5344a2540bcac17e1735d6f1f4a323e143aea618ce6a871953488cbcda4f983f->enter($__internal_5344a2540bcac17e1735d6f1f4a323e143aea618ce6a871953488cbcda4f983f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_5344a2540bcac17e1735d6f1f4a323e143aea618ce6a871953488cbcda4f983f->leave($__internal_5344a2540bcac17e1735d6f1f4a323e143aea618ce6a871953488cbcda4f983f_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
