<?php

/* AdminBundle:AdminDashobard:login/login.html.twig */
class __TwigTemplate_79470f724f4c5572e5e6136389d2267745c21c33716dc7b9010cfec5cb6d80a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AdminBundle:AdminDashobard:base.html.twig", "AdminBundle:AdminDashobard:login/login.html.twig", 1);
        $this->blocks = array(
            'pageTitle' => array($this, 'block_pageTitle'),
            'bodyClass' => array($this, 'block_bodyClass'),
            'navMenu' => array($this, 'block_navMenu'),
            'container' => array($this, 'block_container'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle:AdminDashobard:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af885500d6d7287ec5919bc941008face761f223544a5d0f07c4222e61afc542 = $this->env->getExtension("native_profiler");
        $__internal_af885500d6d7287ec5919bc941008face761f223544a5d0f07c4222e61afc542->enter($__internal_af885500d6d7287ec5919bc941008face761f223544a5d0f07c4222e61afc542_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:AdminDashobard:login/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_af885500d6d7287ec5919bc941008face761f223544a5d0f07c4222e61afc542->leave($__internal_af885500d6d7287ec5919bc941008face761f223544a5d0f07c4222e61afc542_prof);

    }

    // line 3
    public function block_pageTitle($context, array $blocks = array())
    {
        $__internal_d47da8e52639b015daf32804dd3664a154cfdf5ef91dbc01e679a853a135df0d = $this->env->getExtension("native_profiler");
        $__internal_d47da8e52639b015daf32804dd3664a154cfdf5ef91dbc01e679a853a135df0d->enter($__internal_d47da8e52639b015daf32804dd3664a154cfdf5ef91dbc01e679a853a135df0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pageTitle"));

        echo " ";
        
        $__internal_d47da8e52639b015daf32804dd3664a154cfdf5ef91dbc01e679a853a135df0d->leave($__internal_d47da8e52639b015daf32804dd3664a154cfdf5ef91dbc01e679a853a135df0d_prof);

    }

    // line 5
    public function block_bodyClass($context, array $blocks = array())
    {
        $__internal_a6e2e4999cb949326e71d934d0446c8a8dfb09e8d0b053ac0917c94ba8fa683c = $this->env->getExtension("native_profiler");
        $__internal_a6e2e4999cb949326e71d934d0446c8a8dfb09e8d0b053ac0917c94ba8fa683c->enter($__internal_a6e2e4999cb949326e71d934d0446c8a8dfb09e8d0b053ac0917c94ba8fa683c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyClass"));

        echo " login ";
        
        $__internal_a6e2e4999cb949326e71d934d0446c8a8dfb09e8d0b053ac0917c94ba8fa683c->leave($__internal_a6e2e4999cb949326e71d934d0446c8a8dfb09e8d0b053ac0917c94ba8fa683c_prof);

    }

    // line 7
    public function block_navMenu($context, array $blocks = array())
    {
        $__internal_196741f85073736e27cb695b7ef52d10eb5dc482f247a707a87561bae35cf4ad = $this->env->getExtension("native_profiler");
        $__internal_196741f85073736e27cb695b7ef52d10eb5dc482f247a707a87561bae35cf4ad->enter($__internal_196741f85073736e27cb695b7ef52d10eb5dc482f247a707a87561bae35cf4ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navMenu"));

        echo " ";
        
        $__internal_196741f85073736e27cb695b7ef52d10eb5dc482f247a707a87561bae35cf4ad->leave($__internal_196741f85073736e27cb695b7ef52d10eb5dc482f247a707a87561bae35cf4ad_prof);

    }

    // line 9
    public function block_container($context, array $blocks = array())
    {
        $__internal_5c3f711d0e45e971a2a28aaa8e23bc782a18e951ec52d015442431543e0364e3 = $this->env->getExtension("native_profiler");
        $__internal_5c3f711d0e45e971a2a28aaa8e23bc782a18e951ec52d015442431543e0364e3->enter($__internal_5c3f711d0e45e971a2a28aaa8e23bc782a18e951ec52d015442431543e0364e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        echo " 
    ";
        // line 10
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 11
            echo "        <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 13
        echo "    <div>
      <a class=\"hiddenanchor\" id=\"signup\"></a>
      <a class=\"hiddenanchor\" id=\"signin\"></a>

      <div class=\"login_wrapper\">
        <div class=\"animate form login_form\">
          <section class=\"login_content\">
            <form action=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("admin_homepage_login");
        echo "\" method=\"post\">
              <h1>Login Form</h1>
              <div>
                <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />
              </div>
              <div>
                    <input type=\"password\" id=\"password\" name=\"_password\" />
              </div>
              <div>
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('form')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\">
                    <input type=\"hidden\" name=\"_target_path\" value=\"/admin\" />
                <button class=\"btn btn-default submit\" type=\"submit\">login</button>
                <a class=\"reset_pass\" href=\"#\">Lost your password?</a>
              </div>

              <div class=\"clearfix\"></div>
            </form>
          </section>
        </div>
      </div>
    </div>
       

        
    </form>
     ";
        
        $__internal_5c3f711d0e45e971a2a28aaa8e23bc782a18e951ec52d015442431543e0364e3->leave($__internal_5c3f711d0e45e971a2a28aaa8e23bc782a18e951ec52d015442431543e0364e3_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:AdminDashobard:login/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 29,  104 => 23,  98 => 20,  89 => 13,  83 => 11,  81 => 10,  73 => 9,  61 => 7,  49 => 5,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'AdminBundle:AdminDashobard:base.html.twig' %}*/
/* */
/* {% block pageTitle %} {% endblock %}*/
/* */
/* {% block bodyClass %} login {% endblock %}*/
/* */
/* {% block navMenu %} {% endblock %}*/
/* */
/*     {% block container %} */
/*     {% if error %}*/
/*         <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>*/
/*     {% endif %}*/
/*     <div>*/
/*       <a class="hiddenanchor" id="signup"></a>*/
/*       <a class="hiddenanchor" id="signin"></a>*/
/* */
/*       <div class="login_wrapper">*/
/*         <div class="animate form login_form">*/
/*           <section class="login_content">*/
/*             <form action="{{ path('admin_homepage_login') }}" method="post">*/
/*               <h1>Login Form</h1>*/
/*               <div>*/
/*                 <input type="text" id="username" name="_username" value="{{ last_username }}" />*/
/*               </div>*/
/*               <div>*/
/*                     <input type="password" id="password" name="_password" />*/
/*               </div>*/
/*               <div>*/
/*                     <input type="hidden" name="_csrf_token" value="{{ csrf_token('authenticate') }}">*/
/*                     <input type="hidden" name="_target_path" value="/admin" />*/
/*                 <button class="btn btn-default submit" type="submit">login</button>*/
/*                 <a class="reset_pass" href="#">Lost your password?</a>*/
/*               </div>*/
/* */
/*               <div class="clearfix"></div>*/
/*             </form>*/
/*           </section>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/*        */
/* */
/*         */
/*     </form>*/
/*      {% endblock %}   */
