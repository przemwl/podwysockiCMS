<?php

/* AdminBundle:AdminDashobardMain:login.html.twig */
class __TwigTemplate_ad6a5f19be6c8c2fd8a83855bdd66384c3705524ab8016a415119ee135e01de6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef011c63ab7c8213d343d8c0b0ac192bfad20ff7c09728331da9195220271528 = $this->env->getExtension("native_profiler");
        $__internal_ef011c63ab7c8213d343d8c0b0ac192bfad20ff7c09728331da9195220271528->enter($__internal_ef011c63ab7c8213d343d8c0b0ac192bfad20ff7c09728331da9195220271528_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:AdminDashobardMain:login.html.twig"));

        // line 1
        echo "<html>
    <head>
        <title>test</title>
    </head>
    <body>

";
        // line 7
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 8
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 10
        echo "
<form action=\"";
        // line 11
        echo $this->env->getExtension('routing')->getPath("admin_homepage_login");
        echo "\" method=\"post\">
    <label for=\"username\">Username:</label>
    <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />

    <label for=\"password\">Password:</label>
    <input type=\"password\" id=\"password\" name=\"_password\" />

    ";
        // line 23
        echo "    <input type=\"hidden\" name=\"_csrf_token\"
        value=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('form')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"
    >
    
    <input type=\"hidden\" name=\"_target_path\" value=\"/admin\" />

    <button type=\"submit\">login</button>
</form>
    
    

    </body>
</html>
";
        
        $__internal_ef011c63ab7c8213d343d8c0b0ac192bfad20ff7c09728331da9195220271528->leave($__internal_ef011c63ab7c8213d343d8c0b0ac192bfad20ff7c09728331da9195220271528_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:AdminDashobardMain:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 24,  54 => 23,  46 => 13,  41 => 11,  38 => 10,  32 => 8,  30 => 7,  22 => 1,);
    }
}
/* <html>*/
/*     <head>*/
/*         <title>test</title>*/
/*     </head>*/
/*     <body>*/
/* */
/* {% if error %}*/
/*     <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>*/
/* {% endif %}*/
/* */
/* <form action="{{ path('admin_homepage_login') }}" method="post">*/
/*     <label for="username">Username:</label>*/
/*     <input type="text" id="username" name="_username" value="{{ last_username }}" />*/
/* */
/*     <label for="password">Password:</label>*/
/*     <input type="password" id="password" name="_password" />*/
/* */
/*     {#*/
/*         If you want to control the URL the user*/
/*         is redirected to on success (more details below)*/
/*         <input type="hidden" name="_target_path" value="/account" />*/
/*     #}*/
/*     <input type="hidden" name="_csrf_token"*/
/*         value="{{ csrf_token('authenticate') }}"*/
/*     >*/
/*     */
/*     <input type="hidden" name="_target_path" value="/admin" />*/
/* */
/*     <button type="submit">login</button>*/
/* </form>*/
/*     */
/*     */
/* */
/*     </body>*/
/* </html>*/
/* */
