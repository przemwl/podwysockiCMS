<?php

/* AdminBundle:AdminDashobardMain:index.html.twig */
class __TwigTemplate_3469a5441d55a7842d1193855c13f76817d9b4290520ca5ce60e57f098ea5f39 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0df642c3ccfd4638a026d84317eddcc2002a84dbe4e8a308c762ba5be5aa3fab = $this->env->getExtension("native_profiler");
        $__internal_0df642c3ccfd4638a026d84317eddcc2002a84dbe4e8a308c762ba5be5aa3fab->enter($__internal_0df642c3ccfd4638a026d84317eddcc2002a84dbe4e8a308c762ba5be5aa3fab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:AdminDashobardMain:index.html.twig"));

        // line 1
        echo "<html>
    <head>
        <title>test</title>
    </head>
    <body>
        Hello World from Admin! <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("admin_homepage_logout");
        echo "\"> Logout </a>
    </body>
</html>";
        
        $__internal_0df642c3ccfd4638a026d84317eddcc2002a84dbe4e8a308c762ba5be5aa3fab->leave($__internal_0df642c3ccfd4638a026d84317eddcc2002a84dbe4e8a308c762ba5be5aa3fab_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:AdminDashobardMain:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 6,  22 => 1,);
    }
}
/* <html>*/
/*     <head>*/
/*         <title>test</title>*/
/*     </head>*/
/*     <body>*/
/*         Hello World from Admin! <a href="{{ path('admin_homepage_logout') }}"> Logout </a>*/
/*     </body>*/
/* </html>*/
