<?php

/* AdminBundle:AdminDashobard:dashboard-pages/pages.html.twig */
class __TwigTemplate_b954721824de3879ecf22ebdad49aef196cdbfe5a17716fa2fc8e13fec910480 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig", "AdminBundle:AdminDashobard:dashboard-pages/pages.html.twig", 1);
        $this->blocks = array(
            'pageTitle' => array($this, 'block_pageTitle'),
            'bodyClass' => array($this, 'block_bodyClass'),
            'container' => array($this, 'block_container'),
            'leftNavigation' => array($this, 'block_leftNavigation'),
            'topNavigation' => array($this, 'block_topNavigation'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6160a8970e5e8ce908c01b42955c9e43b3b3ecbfd264a655b0f4de0f464b98cb = $this->env->getExtension("native_profiler");
        $__internal_6160a8970e5e8ce908c01b42955c9e43b3b3ecbfd264a655b0f4de0f464b98cb->enter($__internal_6160a8970e5e8ce908c01b42955c9e43b3b3ecbfd264a655b0f4de0f464b98cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:AdminDashobard:dashboard-pages/pages.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6160a8970e5e8ce908c01b42955c9e43b3b3ecbfd264a655b0f4de0f464b98cb->leave($__internal_6160a8970e5e8ce908c01b42955c9e43b3b3ecbfd264a655b0f4de0f464b98cb_prof);

    }

    // line 3
    public function block_pageTitle($context, array $blocks = array())
    {
        $__internal_0118f4eb6509473c08978b1718bc9453df9559cf505caa0c404fc083a7f9be0b = $this->env->getExtension("native_profiler");
        $__internal_0118f4eb6509473c08978b1718bc9453df9559cf505caa0c404fc083a7f9be0b->enter($__internal_0118f4eb6509473c08978b1718bc9453df9559cf505caa0c404fc083a7f9be0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pageTitle"));

        echo " Main Dashboard ";
        
        $__internal_0118f4eb6509473c08978b1718bc9453df9559cf505caa0c404fc083a7f9be0b->leave($__internal_0118f4eb6509473c08978b1718bc9453df9559cf505caa0c404fc083a7f9be0b_prof);

    }

    // line 5
    public function block_bodyClass($context, array $blocks = array())
    {
        $__internal_a83f92e12e4993592403791e6275739911e5c159dc78fa9c6081f0a4d7154406 = $this->env->getExtension("native_profiler");
        $__internal_a83f92e12e4993592403791e6275739911e5c159dc78fa9c6081f0a4d7154406->enter($__internal_a83f92e12e4993592403791e6275739911e5c159dc78fa9c6081f0a4d7154406_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyClass"));

        echo " nav-md ";
        
        $__internal_a83f92e12e4993592403791e6275739911e5c159dc78fa9c6081f0a4d7154406->leave($__internal_a83f92e12e4993592403791e6275739911e5c159dc78fa9c6081f0a4d7154406_prof);

    }

    // line 7
    public function block_container($context, array $blocks = array())
    {
        $__internal_e795809bbc0e70c0620efb694493c97b84c00e71cc33feff20dbd95f6967a40b = $this->env->getExtension("native_profiler");
        $__internal_e795809bbc0e70c0620efb694493c97b84c00e71cc33feff20dbd95f6967a40b->enter($__internal_e795809bbc0e70c0620efb694493c97b84c00e71cc33feff20dbd95f6967a40b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        // line 8
        echo "        
       <div class=\"container body\">
          <div class=\"main_container\">
            <div class=\"col-md-3 left_col\">
                ";
        // line 12
        $this->displayBlock('leftNavigation', $context, $blocks);
        // line 13
        echo "            </div>
            <!-- top navigation -->
            <div class=\"top_nav\">
              ";
        // line 16
        $this->displayBlock('topNavigation', $context, $blocks);
        // line 17
        echo "            </div>
            <!-- /top navigation -->

            <!-- page content -->
            <div class=\"right_col\" role=\"main\">
                <div class=\"row\">
                    <div class=\"col-md-12 col-sm-12 col-xs-12\">
                        
                    </div> <!-- /.col-md-12.col-sm-12.col-xs-12 -->
                </div> <!-- /.row -->
            </div>
            <!-- /page content -->
            <!-- footer content -->
            <footer>
              <div class=\"pull-right\">
                Gentelella - Bootstrap Admin Template by <a href=\"https://colorlib.com\">Colorlib</a>
              </div>
              <div class=\"clearfix\"></div>
            </footer>
            <!-- /footer content -->
          </div>
        </div>

    ";
        
        $__internal_e795809bbc0e70c0620efb694493c97b84c00e71cc33feff20dbd95f6967a40b->leave($__internal_e795809bbc0e70c0620efb694493c97b84c00e71cc33feff20dbd95f6967a40b_prof);

    }

    // line 12
    public function block_leftNavigation($context, array $blocks = array())
    {
        $__internal_f2951a78b92dad852922fb201ad9786963709cf654e208f8c028b4c13c440ff2 = $this->env->getExtension("native_profiler");
        $__internal_f2951a78b92dad852922fb201ad9786963709cf654e208f8c028b4c13c440ff2->enter($__internal_f2951a78b92dad852922fb201ad9786963709cf654e208f8c028b4c13c440ff2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "leftNavigation"));

        $this->displayParentBlock("leftNavigation", $context, $blocks);
        
        $__internal_f2951a78b92dad852922fb201ad9786963709cf654e208f8c028b4c13c440ff2->leave($__internal_f2951a78b92dad852922fb201ad9786963709cf654e208f8c028b4c13c440ff2_prof);

    }

    // line 16
    public function block_topNavigation($context, array $blocks = array())
    {
        $__internal_f353ff519ed2ebd5c4a835965dd0df5bdef863b08371b290ca70576b39d6b7a7 = $this->env->getExtension("native_profiler");
        $__internal_f353ff519ed2ebd5c4a835965dd0df5bdef863b08371b290ca70576b39d6b7a7->enter($__internal_f353ff519ed2ebd5c4a835965dd0df5bdef863b08371b290ca70576b39d6b7a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "topNavigation"));

        $this->displayParentBlock("topNavigation", $context, $blocks);
        
        $__internal_f353ff519ed2ebd5c4a835965dd0df5bdef863b08371b290ca70576b39d6b7a7->leave($__internal_f353ff519ed2ebd5c4a835965dd0df5bdef863b08371b290ca70576b39d6b7a7_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:AdminDashobard:dashboard-pages/pages.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 16,  113 => 12,  83 => 17,  81 => 16,  76 => 13,  74 => 12,  68 => 8,  62 => 7,  50 => 5,  38 => 3,  11 => 1,);
    }
}
/* {% extends 'AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig' %}*/
/* */
/* {% block pageTitle %} Main Dashboard {% endblock %}*/
/* */
/* {% block bodyClass %} nav-md {% endblock %}*/
/* */
/*     {% block container %}*/
/*         */
/*        <div class="container body">*/
/*           <div class="main_container">*/
/*             <div class="col-md-3 left_col">*/
/*                 {% block leftNavigation %}{{ parent() }}{% endblock %}*/
/*             </div>*/
/*             <!-- top navigation -->*/
/*             <div class="top_nav">*/
/*               {% block topNavigation %}{{ parent() }}{% endblock %}*/
/*             </div>*/
/*             <!-- /top navigation -->*/
/* */
/*             <!-- page content -->*/
/*             <div class="right_col" role="main">*/
/*                 <div class="row">*/
/*                     <div class="col-md-12 col-sm-12 col-xs-12">*/
/*                         */
/*                     </div> <!-- /.col-md-12.col-sm-12.col-xs-12 -->*/
/*                 </div> <!-- /.row -->*/
/*             </div>*/
/*             <!-- /page content -->*/
/*             <!-- footer content -->*/
/*             <footer>*/
/*               <div class="pull-right">*/
/*                 Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>*/
/*               </div>*/
/*               <div class="clearfix"></div>*/
/*             </footer>*/
/*             <!-- /footer content -->*/
/*           </div>*/
/*         </div>*/
/* */
/*     {% endblock %}*/
