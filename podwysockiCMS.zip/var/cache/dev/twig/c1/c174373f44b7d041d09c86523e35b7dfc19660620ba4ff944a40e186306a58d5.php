<?php

/* AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig */
class __TwigTemplate_bea02e1921af85b89fde4395e86906f637a4c9ec1af4b63420a6dacb620f4f6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig", "AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig", 1);
        $this->blocks = array(
            'leftNavigation' => array($this, 'block_leftNavigation'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b7135aeb8e54e9e3db3a8769f8c1d8c39104b1ccb365a02b18f0f6bd29513aea = $this->env->getExtension("native_profiler");
        $__internal_b7135aeb8e54e9e3db3a8769f8c1d8c39104b1ccb365a02b18f0f6bd29513aea->enter($__internal_b7135aeb8e54e9e3db3a8769f8c1d8c39104b1ccb365a02b18f0f6bd29513aea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b7135aeb8e54e9e3db3a8769f8c1d8c39104b1ccb365a02b18f0f6bd29513aea->leave($__internal_b7135aeb8e54e9e3db3a8769f8c1d8c39104b1ccb365a02b18f0f6bd29513aea_prof);

    }

    // line 3
    public function block_leftNavigation($context, array $blocks = array())
    {
        $__internal_cedc7bc50df09bbf74f1cc3fa510737126029af8e88df4446581bfd5bc8f56ba = $this->env->getExtension("native_profiler");
        $__internal_cedc7bc50df09bbf74f1cc3fa510737126029af8e88df4446581bfd5bc8f56ba->enter($__internal_cedc7bc50df09bbf74f1cc3fa510737126029af8e88df4446581bfd5bc8f56ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "leftNavigation"));

        // line 4
        echo "<div class=\"left_col scroll-view\">
<div class=\"navbar nav_title\" style=\"border: 0;\">
  <a href=\"index.html\" class=\"site_title\"><i class=\"fa fa-paw\"></i> <span>PodwysockiCMS</span></a>
</div>

<div class=\"clearfix\"></div>

<!-- menu profile quick info -->
<div class=\"profile\">
  <div class=\"profile_pic\">
    <img src=\"images/img.jpg\" alt=\"...\" class=\"img-circle profile_img\">
  </div>
  <div class=\"profile_info\">
    <span>Welcome,</span>
    <h2>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "</h2>
  </div>
</div>
<!-- /menu profile quick info -->

<br />

<!-- sidebar menu -->
<div id=\"sidebar-menu\" class=\"main_menu_side hidden-print main_menu\">
  <div class=\"menu_section\">
    <h3>General</h3>
    <ul class=\"nav side-menu\">
      <li><a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("admin_homepage");
        echo "\"><i class=\"fa fa-home\"></i> Home </a></li>
      <li><a href=\"";
        // line 31
        echo $this->env->getExtension('routing')->getPath("admin_pages");
        echo "\"><i class=\"fa fa-edit\"></i> Pages </a> </li>
    </ul>
  </div>

</div>
<!-- /sidebar menu -->

<!-- /menu footer buttons -->
<div class=\"sidebar-footer hidden-small\">
  <a data-toggle=\"tooltip\" data-placement=\"top\" title=\"Settings\">
    <span class=\"glyphicon glyphicon-cog\" aria-hidden=\"true\"></span>
  </a>
  <a data-toggle=\"tooltip\" data-placement=\"top\" title=\"FullScreen\">
    <span class=\"glyphicon glyphicon-fullscreen\" aria-hidden=\"true\"></span>
  </a>
  <a data-toggle=\"tooltip\" data-placement=\"top\" title=\"Lock\">
    <span class=\"glyphicon glyphicon-eye-close\" aria-hidden=\"true\"></span>
  </a>
  <a data-toggle=\"tooltip\" data-placement=\"top\" title=\"Logout\">
    <span class=\"glyphicon glyphicon-off\" aria-hidden=\"true\"></span>
  </a>
</div>
<!-- /menu footer buttons -->
</div>
  
";
        
        $__internal_cedc7bc50df09bbf74f1cc3fa510737126029af8e88df4446581bfd5bc8f56ba->leave($__internal_cedc7bc50df09bbf74f1cc3fa510737126029af8e88df4446581bfd5bc8f56ba_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:AdminDashobard:dashboard-nav/leftNavigation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 31,  71 => 30,  56 => 18,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig' %}*/
/* */
/* {% block leftNavigation %}*/
/* <div class="left_col scroll-view">*/
/* <div class="navbar nav_title" style="border: 0;">*/
/*   <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span>PodwysockiCMS</span></a>*/
/* </div>*/
/* */
/* <div class="clearfix"></div>*/
/* */
/* <!-- menu profile quick info -->*/
/* <div class="profile">*/
/*   <div class="profile_pic">*/
/*     <img src="images/img.jpg" alt="..." class="img-circle profile_img">*/
/*   </div>*/
/*   <div class="profile_info">*/
/*     <span>Welcome,</span>*/
/*     <h2>{{ app.user.username }}</h2>*/
/*   </div>*/
/* </div>*/
/* <!-- /menu profile quick info -->*/
/* */
/* <br />*/
/* */
/* <!-- sidebar menu -->*/
/* <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">*/
/*   <div class="menu_section">*/
/*     <h3>General</h3>*/
/*     <ul class="nav side-menu">*/
/*       <li><a href="{{ path('admin_homepage') }}"><i class="fa fa-home"></i> Home </a></li>*/
/*       <li><a href="{{ path('admin_pages') }}"><i class="fa fa-edit"></i> Pages </a> </li>*/
/*     </ul>*/
/*   </div>*/
/* */
/* </div>*/
/* <!-- /sidebar menu -->*/
/* */
/* <!-- /menu footer buttons -->*/
/* <div class="sidebar-footer hidden-small">*/
/*   <a data-toggle="tooltip" data-placement="top" title="Settings">*/
/*     <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>*/
/*   </a>*/
/*   <a data-toggle="tooltip" data-placement="top" title="FullScreen">*/
/*     <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>*/
/*   </a>*/
/*   <a data-toggle="tooltip" data-placement="top" title="Lock">*/
/*     <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>*/
/*   </a>*/
/*   <a data-toggle="tooltip" data-placement="top" title="Logout">*/
/*     <span class="glyphicon glyphicon-off" aria-hidden="true"></span>*/
/*   </a>*/
/* </div>*/
/* <!-- /menu footer buttons -->*/
/* </div>*/
/*   */
/* {% endblock %}*/
