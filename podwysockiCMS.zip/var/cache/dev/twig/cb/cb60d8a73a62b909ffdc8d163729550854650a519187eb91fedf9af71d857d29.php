<?php

/* AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig */
class __TwigTemplate_231f9e6ccb636a62f94fd46db12397312b9936fd6dcfd3ec1966e70cbaaff82a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AdminBundle:AdminDashobard:base.html.twig", "AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig", 1);
        $this->blocks = array(
            'topNavigation' => array($this, 'block_topNavigation'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle:AdminDashobard:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_def43c7fbdc6d9f27224d0f461bbe9aa208a889e143c92568360cacb5b1281c8 = $this->env->getExtension("native_profiler");
        $__internal_def43c7fbdc6d9f27224d0f461bbe9aa208a889e143c92568360cacb5b1281c8->enter($__internal_def43c7fbdc6d9f27224d0f461bbe9aa208a889e143c92568360cacb5b1281c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_def43c7fbdc6d9f27224d0f461bbe9aa208a889e143c92568360cacb5b1281c8->leave($__internal_def43c7fbdc6d9f27224d0f461bbe9aa208a889e143c92568360cacb5b1281c8_prof);

    }

    // line 3
    public function block_topNavigation($context, array $blocks = array())
    {
        $__internal_29f40a3804089edff7603ada279134085d708ca60284c51c92bc10815d2f47a9 = $this->env->getExtension("native_profiler");
        $__internal_29f40a3804089edff7603ada279134085d708ca60284c51c92bc10815d2f47a9->enter($__internal_29f40a3804089edff7603ada279134085d708ca60284c51c92bc10815d2f47a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "topNavigation"));

        echo " 
<div class=\"nav_menu\">
    <nav>
      <div class=\"nav toggle\">
        <a id=\"menu_toggle\"><i class=\"fa fa-bars\"></i></a>
      </div>

      <ul class=\"nav navbar-nav navbar-right\">
        <li class=\"\">
          <a href=\"javascript:;\" class=\"user-profile dropdown-toggle\" data-toggle=\"dropdown\" aria-expanded=\"false\">
            <img src=\"images/img.jpg\" alt=\"\">";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "
            <span class=\" fa fa-angle-down\"></span>
          </a>
          <ul class=\"dropdown-menu dropdown-usermenu pull-right\">
            <li><a href=\"javascript:;\"> Profile</a></li>
            <li>
              <a href=\"javascript:;\">
                <span class=\"badge bg-red pull-right\">50%</span>
                <span>Settings</span>
              </a>
            </li>
            <li><a href=\"javascript:;\">Help</a></li>
            <li><a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("admin_homepage_logout");
        echo "\"><i class=\"fa fa-sign-out pull-right\"></i> Log Out</a></li>
          </ul>
        </li>

        <li role=\"presentation\" class=\"dropdown\">
          <a href=\"javascript:;\" class=\"dropdown-toggle info-number\" data-toggle=\"dropdown\" aria-expanded=\"false\">
            <i class=\"fa fa-envelope-o\"></i>
            <span class=\"badge bg-green\">6</span>
          </a>
          <ul id=\"menu1\" class=\"dropdown-menu list-unstyled msg_list\" role=\"menu\">
            <li>
              <a>
                <span class=\"image\"><img src=\"images/img.jpg\" alt=\"Profile Image\" /></span>
                <span>
                  <span>John Smith</span>
                  <span class=\"time\">3 mins ago</span>
                </span>
                <span class=\"message\">
                  Film festivals used to be do-or-die moments for movie makers. They were where...
                </span>
              </a>
            </li>
            <li>
              <a>
                <span class=\"image\"><img src=\"images/img.jpg\" alt=\"Profile Image\" /></span>
                <span>
                  <span>John Smith</span>
                  <span class=\"time\">3 mins ago</span>
                </span>
                <span class=\"message\">
                  Film festivals used to be do-or-die moments for movie makers. They were where...
                </span>
              </a>
            </li>
            <li>
              <a>
                <span class=\"image\"><img src=\"images/img.jpg\" alt=\"Profile Image\" /></span>
                <span>
                  <span>John Smith</span>
                  <span class=\"time\">3 mins ago</span>
                </span>
                <span class=\"message\">
                  Film festivals used to be do-or-die moments for movie makers. They were where...
                </span>
              </a>
            </li>
            <li>
              <a>
                <span class=\"image\"><img src=\"images/img.jpg\" alt=\"Profile Image\" /></span>
                <span>
                  <span>John Smith</span>
                  <span class=\"time\">3 mins ago</span>
                </span>
                <span class=\"message\">
                  Film festivals used to be do-or-die moments for movie makers. They were where...
                </span>
              </a>
            </li>
            <li>
              <div class=\"text-center\">
                <a>
                  <strong>See All Alerts</strong>
                  <i class=\"fa fa-angle-right\"></i>
                </a>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
</div>
";
        
        $__internal_29f40a3804089edff7603ada279134085d708ca60284c51c92bc10815d2f47a9->leave($__internal_29f40a3804089edff7603ada279134085d708ca60284c51c92bc10815d2f47a9_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:AdminDashobard:dashboard-nav/topNavigation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 25,  51 => 13,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AdminBundle:AdminDashobard:base.html.twig' %}*/
/* */
/* {% block topNavigation %} */
/* <div class="nav_menu">*/
/*     <nav>*/
/*       <div class="nav toggle">*/
/*         <a id="menu_toggle"><i class="fa fa-bars"></i></a>*/
/*       </div>*/
/* */
/*       <ul class="nav navbar-nav navbar-right">*/
/*         <li class="">*/
/*           <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">*/
/*             <img src="images/img.jpg" alt="">{{ app.user.username }}*/
/*             <span class=" fa fa-angle-down"></span>*/
/*           </a>*/
/*           <ul class="dropdown-menu dropdown-usermenu pull-right">*/
/*             <li><a href="javascript:;"> Profile</a></li>*/
/*             <li>*/
/*               <a href="javascript:;">*/
/*                 <span class="badge bg-red pull-right">50%</span>*/
/*                 <span>Settings</span>*/
/*               </a>*/
/*             </li>*/
/*             <li><a href="javascript:;">Help</a></li>*/
/*             <li><a href="{{ path('admin_homepage_logout')}}"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>*/
/*           </ul>*/
/*         </li>*/
/* */
/*         <li role="presentation" class="dropdown">*/
/*           <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">*/
/*             <i class="fa fa-envelope-o"></i>*/
/*             <span class="badge bg-green">6</span>*/
/*           </a>*/
/*           <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">*/
/*             <li>*/
/*               <a>*/
/*                 <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>*/
/*                 <span>*/
/*                   <span>John Smith</span>*/
/*                   <span class="time">3 mins ago</span>*/
/*                 </span>*/
/*                 <span class="message">*/
/*                   Film festivals used to be do-or-die moments for movie makers. They were where...*/
/*                 </span>*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a>*/
/*                 <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>*/
/*                 <span>*/
/*                   <span>John Smith</span>*/
/*                   <span class="time">3 mins ago</span>*/
/*                 </span>*/
/*                 <span class="message">*/
/*                   Film festivals used to be do-or-die moments for movie makers. They were where...*/
/*                 </span>*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a>*/
/*                 <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>*/
/*                 <span>*/
/*                   <span>John Smith</span>*/
/*                   <span class="time">3 mins ago</span>*/
/*                 </span>*/
/*                 <span class="message">*/
/*                   Film festivals used to be do-or-die moments for movie makers. They were where...*/
/*                 </span>*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a>*/
/*                 <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>*/
/*                 <span>*/
/*                   <span>John Smith</span>*/
/*                   <span class="time">3 mins ago</span>*/
/*                 </span>*/
/*                 <span class="message">*/
/*                   Film festivals used to be do-or-die moments for movie makers. They were where...*/
/*                 </span>*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <div class="text-center">*/
/*                 <a>*/
/*                   <strong>See All Alerts</strong>*/
/*                   <i class="fa fa-angle-right"></i>*/
/*                 </a>*/
/*               </div>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*       </ul>*/
/*     </nav>*/
/* </div>*/
/* {% endblock %}*/
